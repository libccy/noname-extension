game.import(
	"extension",
	function(lib,game,ui,get,ai,_status){
		return {
			name:"吧友列传",
			content:function (config,pack){
    
			},
			precontent:function (){
				var link = document.createElement("link");
				link.href = lib.assetURL + "extension/吧友列传/extension.css";
				link.type = "text/css";
				link.rel = "stylesheet";
				document.getElementsByTagName("head")[0].appendChild(link);
				game.import(
					'character',
					function(lib,game,ui,get,ai,_status){
						return {
							name:"nonameba",
							connect:true,
							character:{
								
								/*-------------------------第一期-------------------------*/
								
								dachengcheng:["male","BYLZ",4,["daima","chengxu"],["ext:吧友列传/dachengcheng.jpg"]],
								kelejiabing:["male","BYLZ",3,["shuibi","duangeng"],["ext:吧友列传/kelejiabing.jpg"]],
								jielianjun:["male","BYLZ",3,["xiangsu","koutu"],["ext:吧友列传/jielianjun.jpg"]],
								laochanchan:["male","BYLZ",4,["chigua"],["ext:吧友列传/laochanchan.jpg"]],
								xiwangjiaozhu:["male","BYLZ",4,["jiwang","guangmang"],["ext:吧友列传/xiwangjiaozhu.jpg"]],
								manduxun:["male","BYLZ",5,["shuiyou","qiji"],["ext:吧友列传/manduxun.jpg"]],
								bohetang:["female","BYLZ",3,["yaowan","bohe"],["ext:吧友列传/bohetang.jpg"]],
								jiaotang:["male","BYLZ",4,["qianshui","maopao"],["ext:吧友列传/jiaotang.jpg"]],
								
								/*-------------------------第二期-------------------------*/
								
								xueyan531:["male","BYLZ",4,["fenzhi"],["ext:吧友列传/xueyan531.jpg"]],
								Sukincen:["male","BYLZ",3,["cxytansuo","cxykaobei"],["ext:吧友列传/Sukincen.jpg"]],
								liusha:["male","BYLZ",4,["cxysucai","cxyweitiao"],["ext:吧友列传/liusha.jpg"]],
								jianxiake:["female","BYLZ",3,["cxybaihe","cxysanren"],["ext:吧友列传/jianxiake.jpg"]],
								
							},
							characterTitle:{
								
								/*-------------------------第一期-------------------------*/
								
								dachengcheng:"#b吧友形象:丶橙续缘",
								kelejiabing:"#b吧友形象:可乐加冰24",
								jielianjun:"#b吧友形象:戒除联盟",
								laochanchan:"#b吧友形象:剑晨雨殇",
								xiwangjiaozhu:"#b吧友形象:不幸º狛枝",
								manduxun:"#b吧友形象:神99满都迅",
								bohetang:"#b吧友形象:薄荷糖的0味道",
								jiaotang:"#b吧友形象:椒盐焦糖君",
								
								/*-------------------------第二期-------------------------*/
								
								xueyan531:"#b吧友形象：焱血531",
								Sukincen:"#b吧友形象：Sukincen",
								liusha:"#b吧友形象：_游离感_",
								jianxiake:"#b吧友形象：小鬼常昊灵",
								
							},
							skill:{
								
								/*-------------------------第一期-------------------------*/
								
								daima:{
									mod:{
										targetInRange:function(card,player,target,now){
											if(card.name=="sha"&&target.hp<player.hp)return true;
										}
									},
								},
								chengxu:{
									trigger:{player:"shaBegin"},
									filter:function(event,player){
										return get.number(event.card)&&event.target.hp<get.number(event.card);
									},
									logTarget:"target",
									check:function(event,player){
										return get.attitude(player,event.target)<2;
									},
									content:function(){
										"step 0"
										trigger.directHit=true;
										"step 1"
										trigger.target.discard(trigger.target.getCards('he',{subtype:'equip2'}));
									},
								},
								shuibi:{
									trigger:{global:"phaseUseBegin"},
									filter:function(event,player){
										return event.player!=player&&player.num('h')&&event.player.num('h')>=player.num('h');
									},
									logTarget:"player",
									check:function(event,player){
										if(get.attitude(player,event.player)<2){
											return true;
										}
										else {
											return event.player.num>6;
										}
									},
									content:function(){
										"step 0"
										if(trigger.player.countCards('h')==0||player.countCards('h')==0){
											event.finish();
											return;
										}
										"step 1"
										var sendback=function(){
											if(_status.event!=event){
												return function(){
													event.resultOL=_status.event.resultOL;
												};
											}
										};
										if(player.isOnline()){
											player.wait(sendback);
											event.ol=true;
											player.send(function(){
												game.me.chooseCard(true).set('glow_result',true).ai=function(){
													return Math.random();
												};
												game.resume();
											});
										}
										else{
											event.localPlayer=true;
											player.chooseCard(true).set('glow_result',true).ai=function(){
												return Math.random();
											};
										}
										if(trigger.player.isOnline()){
											trigger.player.wait(sendback);
											event.ol=true;
											trigger.player.send(function(){
												var rand=Math.random()<0.4;
												game.me.chooseCard(true).set('glow_result',true).ai=function(card){
													return 12-get.useful(card) + Math.random();
												};
												game.resume();
											});
										}
										else{
											event.localTarget=true;
										}
										"step 2"
										if(event.localPlayer){
											event.card1=result.cards[0];
										}
										if(event.localTarget){
											var rand=Math.random()<0.4;
											trigger.player.chooseCard(true).set('glow_result',true).ai=function(card){
												return 12-get.useful(card) + Math.random();
											};
										}
										"step 3"
										if(event.localTarget){
											event.card2=result.cards[0];
										}
										if(!event.resultOL&&event.ol){
											game.pause();
										}
										"step 4"
										try{
											if(!event.card1) event.card1=event.resultOL[player.playerid].cards[0];
											if(!event.card2) event.card2=event.resultOL[trigger.player.playerid].cards[0];
											if(!event.card1||!event.card2){
												throw('err');
											}
										}
										catch(e){
											console.log(e);
											event.finish();
											return;
										}
										if(event.card2.number>=10||event.card2.number<=4){
											if(trigger.player.countCards('h')>2){
												event.addToAI=true;
											}
										}
										game.broadcastAll(function(card1,card2){
											card1.classList.remove('glow');
											card2.classList.remove('glow');
										},event.card1,event.card2);
										"step 5"
										game.broadcastAll(function(){
											ui.arena.classList.add('thrownhighlight');
										});
										game.addVideo('thrownhighlight1');
										player.$compare(event.card1,trigger.player,event.card2);
										game.delay(4);
										"step 6"
										game.log(player,'展示了',event.card1);
										game.log(trigger.player,'展示了',event.card2);
										var num1=event.card1.number;
										var num2=event.card2.number;
										if((num1+num2)%2==0){
											trigger.player.discard(event.card2);
											player.$gain2(event.card1);
											var clone=event.card2.clone;
											if(clone){
												clone.style.transition='all 0.5s';
												clone.style.transform='scale(1.2)';
												clone.delete();
												game.addVideo('deletenode',trigger.player,get.cardsInfo([clone]));
											}
											game.broadcast(function(card){
												var clone=card.clone;
												if(clone){
													clone.style.transition='all 0.5s';
													clone.style.transform='scale(1.2)';
													clone.delete();
												}
											},event.card2);
											player.draw();
										}
										else{
											player.$gain2(event.card1);
											trigger.player.$gain2(event.card2);
										}
										game.broadcastAll(function(){
											ui.arena.classList.remove('thrownhighlight');
										});
										game.addVideo('thrownhighlight2');
									}
								},
								duangeng:{
									unique:true,
									mark:true,
									marktext:"觉",
									intro:{
										content:"limited",
									},
									skillAnimation:true,
									animationColor:"thunder",
									trigger:{player:"phaseBegin"},
									filter:function(event,player){
										if(player.storage.duangeng)return false;
										if(player.storage.duangeng_draw==undefined){
											player.storage.duangeng_draw=0;
											return false;
										}
										if(player.storage.duangeng_draw<game.roundNumber){
											return true;
										}
										else {
											player.storage.duangeng_draw=0;
											return false;
										}
									},
									forced:true,
									content:function(){
										"step 0"
										player.storage.duangeng = true;
										player.awakenSkill("duangeng");
										"step 1"
										player.gainMaxHp();
										player.removeSkill("shuibi");
									},
									group:["duangeng_gain"],
									subSkill:{
										gain:{
											trigger:{player:'gainAfter'},
											direct:true,
											filter:function(event,player){
												if(event.parent.parent.name=='phaseDraw') return false;
												return event.cards&&event.cards.length>0
											},
											content:function(){
												if(player.storage.duangeng_draw==undefined){
													player.storage.duangeng_draw=0;
												}
												player.storage.duangeng_draw+=trigger.cards.length;
											}
										},
									},
								},
								xiangsu:{
									init:function(player){
										player.storage.xiangsu_name = {};
										player.storage.xiangsu=0;
										player.storage.xiangsu_name_get = 1;
										player.storage.xiangsu_name_list = [];
										
										for(var i=0;i<ui.cardPile.childNodes.length;i++){
											if(get.type(ui.cardPile.childNodes[i])!="trick")continue;
											if(!player.storage.xiangsu_name_list.contains(ui.cardPile.childNodes[i].name)){
												player.storage.xiangsu_name_list.push(ui.cardPile.childNodes[i].name);
											}
										}
									},
									getXiangSu:function(player){
										var count = 0;
										for(var i in player.storage.xiangsu_name){
											count ++;
										}
										if(count==player.storage.xiangsu_name_list.length){
											return;
										}
										while(1){
											var name = player.storage.xiangsu_name_list.randomGet();
											if(player.storage.xiangsu_name[name]){
												continue;
											}
											else {
												player.storage.xiangsu_name[name] = player.storage.xiangsu_name_get;
												player.storage.xiangsu_name_get++;
												player.storage.xiangsu++;
												player.popup(name);
												break;
											}
										}
										player.syncStorage("xiangsu");
									},
									mark:true,
									marktext:"素",
									intro:{
										content:function(storage,player){
											var str = "<p>当前拥有的像素：</p>",count = 0;
											str += "<center>"
											for(var i in player.storage.xiangsu_name){
												str += get.translation(i) + "("+player.storage.xiangsu_name[i]+")<br>";
												count++;
											}
											if(count==0){
												str += "暂未获得像素"
											}
											str += "</center>"
											return str;
										}
									},
									trigger:{player:"useCard"},
									filter:function(event,player){
										if(_status.currentPhase!=player||player.storage.xiangsu_name_type==undefined){
											return false;
										}
										return !player.storage.xiangsu_name_type.contains(get.type(event.card));
									},
									content:function(){
										"step 0"
										player.draw();
										lib.skill["xiangsu"].getXiangSu(player);
										"step 1"
										player.storage.xiangsu_name_type.push(get.type(trigger.card));
									},
									group:["xiangsu_phaseUseBegin","xiangsu_phaseUseAfter"],
									subSkill:{
										phaseUseBegin:{
											trigger:{player:"phaseUseBegin"},
											direct:true,
											content:function(){
												player.storage.xiangsu_name_type = [];
											}
										},
										phaseUseAfter:{
											trigger:{player:"phaseUseAfter"},
											direct:true,
											content:function(){
												delete player.storage.xiangsu_name_type;
											}
										},
									},
								},
								koutu:{
									enable:"phaseUse",
									filter:function(event,player){
										if(player.storage.xiangsu_name==undefined)return false;
										for(var i in player.storage.xiangsu_name){
											return true;
										}
										return false;
									},
									chooseButton:{
										dialog:function(event,player){
											var list = [];
											for(var i in player.storage.xiangsu_name){
												list.push(i);
											}
											for(var i=0;i<list.length;i++){
												list[i] = ["锦囊",player.storage.xiangsu_name[list[i]],list[i]];
											}
											return ui.create.dialog([list,'vcard']);
										},
										filter:function(button,player){
											return lib.filter.filterCard({name:button.link[2]},player,_status.event.getParent());
										},
										check:function(button){
											var player=_status.currentPhase;
											var filterCard = player.getCards('h',function(card){
												return get.number(card)<=player.storage.xiangsu_name[button.link[2]];
											});
											var bool = false;
											for(var i=0;i<filterCard.length;i++){
												if(get.number(filterCard[i])==player.storage.xiangsu_name[button.link[2]]){
													bool = true;
													break;
												}
												else {
													for(j=i+1;j<filterCard.length;j++){
														if(get.number(filterCard[i])+get.number(filterCard[j])==player.storage.xiangsu_name[button.link[2]]){
															bool = true;
															break;
														}
													}
												}
											}
											var players=game.filterPlayer();
											if(!bool)return 0;
											if(button.link[2]=='wuzhong'||button.link[2]=='zengbing'){
												return 3+Math.random();
											}
											if(button.link[2]=='juedou'){
												return 2+Math.random();
											}
											if(button.link[2]=='guohe'){
												return 2+Math.random();
											}
											if(button.link[2]=='shunshou'){
												for(var i=0;i<players.length;i++){
													if(player.canUse('shunshou',players[i])&&get.attitude(player,players[i])<0){
														return 2+Math.random();
													}
												}
												return 0;
											}
											if(button.link[2]=='tiesuo'){
												return 1+Math.random();
											}
											if(button.link[2]=='nanman'||button.link[2]=='wanjian'||button.link[2]=='taoyuan'||button.link[2]=='wugu'){
												var eff=0;
												for(var i=0;i<players.length;i++){
													if(players[i]!=player){
														eff+=get.effect(players[i],{name:button.link[2]},player,player);
													}
												}
												if(eff>0){
													return 1+Math.random();
												}
												return 0;
											}
											return Math.random();

										},
										backup:function(links,player){
											return {
												complexCard:true,
												filterCard:function(card){
													var player = _status.currentPhase;
													if(ui.selected.cards.length==0){
														return get.number(card)<=player.storage.xiangsu_name[links[0][2]];
													}
													else if(ui.selected.cards.length==1){
														return get.number(ui.selected.cards[0])+get.number(card)<=player.storage.xiangsu_name[links[0][2]];
													}
													else if(ui.selected.cards.length==2){
														return get.number(ui.selected.cards[0])+get.number(ui.selected.cards[1])+get.number(card)==player.storage.xiangsu_name[links[0][2]];
													}
												},
												selectCard:function(){
													var num = 0;
													for(var i=0;i<ui.selected.cards.length;i++){
														num += get.number(ui.selected.cards[i]);
													}
													if(num==player.storage.xiangsu_name[links[0][2]]){
														return ui.selected.cards.length;
													}
													else {
														return Math.min(3,ui.selected.cards.length+1);
													}
												},
												popname:true,
												check:function(card){
													var num=0;
													for(var i=0;i<ui.selected.cards.length;i++){
														num+=get.number(ui.selected.cards[i]);
													}
													if(num+get.number(card)==player.storage.xiangsu_name[links[0][2]]) return 2*get.value(links[0][2])-get.value(card);
													if(ui.selected.cards.length==0){
														var cards=player.getCards('h');
														for(var i=0;i<cards.length;i++){
															for(var j=i+1;j<cards.length;j++){
																if(cards[i].number+cards[j].number==player.storage.xiangsu_name[links[0][2]]){
																	if(cards[i]==card||cards[j]==card) return 2*get.value(links[0][2])-get.value(card);
																}
															}
														}
													}
													return 0;
												},
												viewAs:{name:links[0][2]},
												onuse:function(result,player){
													delete player.storage.xiangsu_name[links[0][2]];
													player.storage.xiangsu--;
													player.syncStorage("xiangsu");
												},
											}
										},
										prompt:function(links,player){
											return "请选择至多三张点数之和为"+get.cnNumber(player.storage.xiangsu_name[links[0][2]])+"的手牌";
										}
									},
									ai:{
										order:10,
										result:{
											player:1,
										},
									},
								},
								chigua:{
									group:["chigua_buff0","chigua_buff1","chigua_buff2"],
									init:function(player){
										player.storage.chigua_list = ["使用[杀]无距离限制","使用[杀]额外指定一名目标","使用[杀]的次数限制+1"];
									},
									trigger:{player:"damageEnd"},
									forced:true,
									content:function(){
										"step 0"
										if(player.storage.chigua_list.length==0){
											player.draw(2);
											event.finish();
										}
										else {
											player.draw();
										}
										"step 1"
										player.chooseControl(player.storage.chigua_list,function(event,player){
											return player.storage.chigua_list.randomGet();
										}).prompt="吃瓜：选择获得一项永久效果";
										"step 2"
										player.storage.chigua_list.remove(result.control);
										if(result.control=="使用[杀]无距离限制"){
											player.storage.chigua_buff0 = true;
										}
										else if(result.control=="使用[杀]额外指定一名目标"){
											player.storage.chigua_buff1 = true;
										}
										else {
											player.storage.chigua_buff2 = true;
										}
									},
									subSkill:{
										buff0:{
											mod:{
												targetInRange:function(card,player,target,now){
													if(card.name=='sha'&&player.storage.chigua_buff0)return true;
												}
											},
										},
										buff1:{
											mod:{
												selectTarget:function(card,player,range){
													if(player.storage.chigua_buff1&&card.name=='sha'&&range[1]!=-1){
														range[1]++;
													}
												}
											},
										},
										buff2:{
											mod:{
												cardUsable:function(card,player,num){
													if(player.storage.chigua_buff2&&card.name=='sha'){
														return num+1;
													}
												}
											},
										},
									},
								},
								jiwang:{
									init:function(player){
										player.storage.jiwang = [];
									},
									marktext:"望",
									intro:{
										name:"寄望",
										content:"cards",
									},
									trigger:{player:"damageEnd"},
									filter:function(event,player){
										return !player.hasSkill("jiwang_filter")&&game.hasPlayer(function(current){
											return current.num('ej');
										});
									},
									direct:true,
									content:function(){
										"step 0"
										player.chooseTarget("寄望：是否将场上的一张牌置于你的武将牌上？",function(card,player,target){
											return target.num('ej');
										}).ai=function(target){
											if(get.attitude(player,target)>2){
												return target.num('j')?20:-20;
											}
											if(target.num('e')==0)return 0;
											var value = 0;
											for(var i=0;i<target.getCards('e').length;i++){
												value = Math.max(value,get.value(target.getCards('e')[i]));
											}
											return value;
										};
										"step 1"
										if(result.bool){
											event.target = result.targets[0];
											player.logSkill("jiwang",result.targets);
											player.addTempSkill("jiwang_filter",{player:"phaseBefore"});
											var dialog = ui.create.dialog("hidden");
											if(result.targets[0].num('j')){
												dialog.add("判定区");
												dialog.add(result.targets[0].getCards('j'));
											}
											if(result.targets[0].num('e')){
												dialog.add("装备区");
												dialog.add(result.targets[0].getCards('e'));
											}
											player.chooseButton(dialog,true).set('ai',function(button){
												if(get.attitude(player,result.targets[0])>2){
													if(get.position(button.link)=='j'){
														return 20 + get.value(button.link);
													}
													else {
														return Math.random();
													}
												}
												if(get.position(button.link)=='j')return 0;
												return get.value(button.link);
											});
										}
										else {
											event.finish();
										}
										"step 2"
										if(result.bool){
											player.storage.jiwang=player.storage.jiwang.concat(result.links);
											player.markSkill('jiwang');
											player.syncStorage('jiwang');
											event.target.lose(result.links,ui.special);
											event.target.$give(result.links,player);
										}
										else {
											event.finish();
										}
									},
									ai:{
										maixie:true,
										maixie_hp:true,
										effect:{
											target:function(card,player,target){
												if(get.tag(card,'damage')&&!target.hasSkill("jiwang_filter")){
													if(player.hasSkillTag("jueqing")||!game.hasPlayer(function(current){
														return (current.num('j')&&get.attitude(player,current)<2)||(current.num('e')&&get.attitude(player,current)>2)
													}))return [1,-2];
													if(!target.hasFriend())return ;
													if(target.hp>3)return [0.5,1.5];
												}
											}
										}
									},
									subSkill:{
										filter:{},
									},
								},
								guangmang:{
									trigger:{player:"phaseBegin"},
									filter:function(event,player){
										return player.storage.jiwang&&player.storage.jiwang.length;
									},
									forced:true,
									content:function(){
										"step 0"
										for(var i=0;i<player.storage.jiwang.length;i++){
											ui.discardPile.appendChild(player.storage.jiwang[i]);
										}
										player.$throw(player.storage.jiwang);
										player.storage.jiwang = [];
										player.unmarkSkill("jiwang");
										"step 1"
										player.recover();
										"step 2"
										player.chooseTarget("光芒：你可以视为使用一张[杀](无距离限制)",function(card,player,target){
											return player.canUse({name:"sha"},target,false);
										}).ai=function(target){
											return get.effect(target,{name:"sha"},player,player);
										};
										"step 3"
										if(result.bool){
											player.useCard({name:"sha"},result.targets,false);
										}
									}
								},
								shuiyou:{
									mod:{
										maxHandcard:function(player,num){
											return num + (player.storage.shuiyou?player.storage.shuiyou:0);
										},
									},
									intro:{
										content:function(storage,player){
											return "手牌上限+"+storage;
										}
									},
									group:["shuiyou_damage","shuiyou_draw"],
									subSkill:{
										damage:{
											trigger:{player:"damageEnd"},
											forced:true,
											content:function(){
												if(player.storage.shuiyou==undefined){
													player.storage.shuiyou=0;
												}
												player.storage.shuiyou+=trigger.num;
												player.syncStorage("shuiyou");
												player.markSkill("shuiyou");
											}
										},
										draw:{
											trigger:{player:"phaseDrawBegin"},
											forced:true,
											content:function(){
												trigger.num = player.maxHp - player.hp;
											}
										},
									}, 
								},
								qiji:{
									trigger:{player:"phaseUseAfter"},
									forced:true,
									content:function(){
										"step 0"
										if(game.hasPlayer(function(current){
											return current.num('h')>player.num('h');
										})){
											player.draw();
											
											if(!game.hasPlayer(function(current){
												return current.num('ej');
											})){event.finish();}
										}
										else {
											player.loseHp();
											event.finish();
										}
										"step 1"
										player.chooseTarget("奇迹：弃置场上的一张牌",function(card,player,target){
											return target.num('ej');
										},true).ai=function(target){
											if(get.attitude(player,target)>2&&target.num('j')){
												return 10 + Math.random();
											}
											if(get.attitude(player,target)<2&&target.num('e')){
												return 5 + Math.random();
											}
											return Math.random();
										};
										"step 2"
										player.line(result.targets,"green");
										player.discardPlayerCard(result.targets[0],"ej",true).ai=function(card){
											if(get.position(card)=='j'){
												if(get.attitude(player,target)>2)return 10 + get.value(card);
												return Math.random();
											}
											if(get.position(card)=='e'){
												if(get.attitude(player,target)<2)return get.value(card);
												return Math.random();
											}
										};
									}
								},
								yaowan:{
									trigger:{player:["gainAfter","loseEnd"],global:"gameDrawAfter"},
									forced:true,
									filter:function(event,player){
										return player.num('h')>0;
									},
									content:function(){
										player.discard(player.getCards('h'));
									}
								},
								bohe:{
									group:["bohe_use","bohe_respond"],
									filter:function(event,player){
										return false;
									},
									viewAs:{name:'wuxie'},
									ai:{
										respondSha:true,
										respondShan:true,
										save:true,
									},
									subSkill:{
										use:{
											enable:'chooseToUse',
											chooseButton:{
												dialog:function(event,player){
													if(ui.cardPile.childNodes.length<5){
														var cards=get.cards(ui.cardPile.childElementCount+1);
														for(var i=0;i<cards.length;i++){
															ui.cardPile.insertBefore(cards[i],ui.cardPile.childNodes[get.rand(ui.cardPile.childElementCount)]);
														}
													}
													player.storage.bohe = [
														ui.cardPile.childNodes[0],
														ui.cardPile.childNodes[1],
														ui.cardPile.childNodes[2],
														ui.cardPile.childNodes[3],
														ui.cardPile.childNodes[4],
													];
													return ui.create.dialog('薄荷',player.storage.bohe,'hidden');
												},
												filter:function(button,player){
													var evt=_status.event.getParent();
													if(evt&&evt.filterCard){
														return evt.filterCard(button.link,player,evt);
													}
													return true;
												},
												check:function(button){
													var player = _status.currentPhase;
													return game.hasPlayer(function(current){
														return player.canUse(button.link,current,false)&&get.effect(current,button.link,player,player)>0;
													})?get.order(button.link):0;
												},
												backup:function(links,player){
													return {
														filterCard:function(){return false},
														selectCard:-1,
														viewAs:links[0],
														onuse:function(result,player){
															delete player.storage.bohe;
														}
													}
												},
												prompt:function(links,player){
													return '选择'+get.translation(links)+'的目标';
												}
											},
											ai:{
												order:4,
												result:{
													player:function(player){
														
															return 1;
														for(var i=0;i<5;i++){
															var card = ui.cardPile.childNodes[i];
															if(game.hasPlayer(function(current){
																var evt=_status.event.getParent();
																if(evt&&evt.filterCard){
																	return evt.filterCard(button.link,player,evt)&&game.hasPlayer(function(current){
																		return player.canUse(button.link,current,false)&&get.effect(current,card,player,player)>0;
																	});
																}
																return game.hasPlayer(function(current){
																	return get.effect(current,card,player,player)>0;
																});
															}))
															return 1;
														}
														return 0;
													}
												},
												useful:-1,
												value:-1
											}
										},
										respond:{
											trigger:{player:'chooseToRespondBegin'},
											filter:function(event,player){
												if(event.responded) return false;
												return true;
											},
											content:function(){
												"step 0"
												var cards=[];
												if(ui.cardPile.childNodes.length<5){
													var discardcards=get.cards(5);
													for(var i=0;i<discardcards.length;i++){
														ui.discardPile.appendChild(discardcards[i]);
													}
												}
												for(var i=0;i<5;i++){
													cards.push(ui.cardPile.childNodes[i]);
												}
												player.chooseCardButton('薄荷：选择一张卡牌打出',cards).set('filterButton',function(button){
													return _status.event.getTrigger().filterCard(button.link);
												});
												"step 1"
												if(result.bool){                                    
													trigger.untrigger();
													trigger.responded=true;
													result.links[0].remove();
													trigger.result={bool:true,card:result.links[0]}
												}
											},
											ai:{
												effect:{
													target:function(card,player,target,effect){
														if(get.tag(card,'respondShan')) return 0.7;
														if(get.tag(card,'respondSha')) return 0.7;
													}
												}
											},
										},
									},
								},
								qianshui:{
									trigger:{player:"phaseEnd"},
									filter:function(event,player){
										return player.num("e");
									},
									content:function(){
										"step 0"
										event.num = player.num('e')
										player.draw(event.num);
										"step 1"
										player.chooseToDiscard(event.num,"he",true).ai=function(card){
											if(get.type(card)=='equip'){
												for(var i=0;i<ui.selected.cards.length;i++){
													if(get.type(ui.selected.cards[i])=='equip'){
														return 6-get.value(card);
													}
												}
												return 8-get.value(card);
											}
											return 6-get.value(card)
										};
										"step 2"
										for(var i=0;i<result.cards.length;i++){
											if(get.type(result.cards[i])=="equip"){
												player.addTempSkill("qianshui_distance",{player:"phaseBegin"});
												break;
											}
										}
									},
									subSkill:{
										distance:{
											mark:true,
											marktext:"潜",
											intro:{
												name:"潜水",
												content:"防御距离+1",
											},
											mod:{
												globalTo:function(from,to,distance){
													return distance+1;
												}
											}
										},
									},
								},
								maopao:{
									group:["maopao_source","maopao_player"],
									subSkill:{
										source:{
											trigger:{source:"damageEnd"},
											filter:function(event,player){
												return event.player.isAlive()&&event.player.num("e");
											},
											check:function(event,player){
												return get.attitude(player,event.player)<2;
											},
											logTarget:"player",
											content:function(){
												"step 0"
												player.chooseCardButton("冒泡：选择移动一张装备牌",trigger.player.getCards("e")).set("filterButton",function(button){
													return game.hasPlayer(function(current){
														return current.countCards("e",{subtype:get.subtype(button.link)})==0;
													})
												}).set("ai",function(button){
													return get.value(button.link);
												});
												"step 1"
												if(result.bool){
													event.card = result.links[0];
													player.chooseTarget("冒泡：将"+get.translation(event.card)+"置入一名角色的装备区",function(card,player,target){
														return target.countCards("e",{subtype:get.subtype(event.card)})==0;
													}).ai=function(target){
														return get.attitude(player,target);
													};
												}
												else {
													event.finish();
												}
												"step 2"
												if(result.bool){
													trigger.player.$give(event.card,result.targets[0]);
													result.targets[0].equip(event.card);
												}
												else {
													event.finish();
												}
											}
										},
										player:{
											trigger:{player:"damageEnd"},
											filter:function(event,player){
												return event.source&&event.source.isAlive()&&player.num("e");
											},
											direct:true,
											content:function(event,player){
												var next = trigger.source.discardPlayerCard("是否对"+get.translation(player)+"发动冒泡？弃置其一张装备区的牌",player,"e");
												next.ai=function(card){
													if(get.attitude(trigger.source,trigger.player)>2){
														return 0;
													}
													return get.value(card);
												};
												next.logSkill = "maopao";
												next.set("logTarget","player");
											}
										},
									},
								},
							
								/*-------------------------第二期-------------------------*/
								
								fenzhi:{
									usable:1,
									trigger:{player:"damageEnd"},
									content:function(){
										"step 0"
										player.draw();
										if(!trigger.source||!trigger.source.isAlive()){
											event.finish();
										}
										"step 1"
										player.chooseCard("分置：选择展示一张手牌","h",true);
										"step 2"
										event.card = result.cards[0];
										player.showCards(event.card);
										player.line(trigger.source,"BYLZ");
										"step 3"
										trigger.source.chooseControl("选项一","选项二",function(event,player){
											if(trigger.source.countCards('he',{type:"equip"})){
												if(_status.currentPhase==trigger.source&&trigger.source.num('h')>4)return "选项一";
												return "选项二";
											}
											return "选项一";
										}).prompt = "分置：请选择一项<p>选项一：摸一张牌，然后翻面</p><p>选项二：弃一张装备牌</p>";
										"step 4"
										if(result.control=="选项一"){
											trigger.source.draw();
											trigger.source.turnOver();
											event.finish();
										}
										else {
											trigger.source.chooseToDiscard("分置：弃置一张装备牌","he",{type:"equip"}).ai=function(card){
												return 12 - get.value(card);
											};
										}
										"step 5"
										if(result.bool){
											var str = "";
											if(get.type(event.card)=="trick"||get.type(event.card)=="delay"){
												trigger.source.storage.fenzhi_ban = ["trick","delay"];
												str = "锦囊";
											}
											else {
												trigger.source.storage.fenzhi_ban = get.type(event.card);
												str = get.translation(get.type(event.card));
											}
											trigger.source.markSkillCharacter('fangquan_ban',player,'分置','不能使用或打出'+str+'牌');
											trigger.source.addTempSkill("fenzhi_ban",{player:"phaseBegin"});
										}
										else {
											event.goto(3);
										}
									},
									subSkill:{
										ban:{
											mod:{
												cardEnabled:function(card,player){
													if(typeof player.storage.fenzhi_ban=="string"){
														if(get.type(card)==player.storage.fenzhi_ban) return false;
													}
													else {
														if(player.storage.fenzhi_ban.contains(get.type(card)))return false;
													}
												},
												cardUsable:function(card,player){
													if(typeof player.storage.fenzhi_ban=="string"){
														if(get.type(card)==player.storage.fenzhi_ban) return false;
													}
													else {
														if(player.storage.fenzhi_ban.contains(get.type(card)))return false;
													}
												},
												cardRespondable:function(card,player){
													if(typeof player.storage.fenzhi_ban=="string"){
														if(get.type(card)==player.storage.fenzhi_ban) return false;
													}
													else {
														if(player.storage.fenzhi_ban.contains(get.type(card)))return false;
													}
												},
												cardSavable:function(card,player){
													if(typeof player.storage.fenzhi_ban=="string"){
														if(get.type(card)==player.storage.fenzhi_ban) return false;
													}
													else {
														if(player.storage.fenzhi_ban.contains(get.type(card)))return false;
													}
												}
											},
											onremove:function(player){
												player.unmarkSkill("fenzhi_ban");
												delete player.storage.fenzhi_ban;
											}
										},
									},
								},
								cxytansuo:{
									trigger:{player:"damageEnd"},
									filter:function(event,player){
										return player.num('he');
									},
									direct:true,
									content:function(){
										"step 0"
										var skillprompt = "是否发动<cS>探索</cS>？";
										skillprompt += "<p>"+get.translation("cxytansuo_info")+"</p>"
										player.chooseBool(skillprompt).ai=function(){
											return true;
										};
										"step 1"
										if(result.bool){
											player.chooseToDiscard("探索：选择弃置一张牌","he").ai=function(card){
												if(player.hasSkill("cxykaobei")){
													if(get.position(card)=="e")return 15 - get.value(card);
												}
												return 12 - get.value(card);
											};
										}
										else {
											event.finish();
										}
										"step 2"
										if(result.bool){
											player.logSkill("cxytansuo");
											player.chooseControl("基本牌","锦囊牌","装备牌",function(event,player){
												return ["基本牌","锦囊牌","装备牌"].randomGet();
											}).prompt = "探索：声明一种牌的类型";
										}
										else {
											event.goto(0);
										}
										"step 3"
										if(result.control=="基本牌"){
											event.type = ["basic"];
										}
										else if(result.control=="锦囊牌"){
											event.type = ["trick","delay"];
										}
										else {
											event.type = ["equip"];
										}
										player.popup(result.control);
										event.cards = get.cards(5);
										player.showCards("探索展示",event.cards);
										"step 4"
										for(var i=0;i<event.cards.length;i++){
											if(!event.type.contains(get.type(event.cards[i]))){
												ui.discardPile.appendChild(event.cards[i]);
												event.cards.remove(event.cards[i--]);
											}
										}
										if(event.cards.length){
											player.gain(event.cards);
											player.$draw(event.cards);
										}
									}
								},
								cxykaobei:{
									trigger:{player:"discard"},
									filter:function(event,player){
										for(var i=0;i<event.cards.length;i++){
											if(event.cards[i].original=='e')return true;
										}
										return false;
									},
									direct:true,
									content:function(){
										"step 0"
										var skillprompt = "是否发动<cS>拷贝</cS>？";
										skillprompt += "<p>"+get.translation("cxykaobei_info")+"</p>";
										player.chooseBool(skillprompt).ai=function(){
											return game.hasPlayer(function(current){
												return current!=player&&get.attitude(player,current)<2;
											});
										};
										"step 1"
										if(result.bool){
											player.chooseTarget("拷贝：选择发动对象",function(card,player,target){
												return target!=player&&target.num('he');
											}).ai=function(target){
												return 2 - get.attitude(player,target);
											};
										}
										else {
											event.finish();
										}
										"step 2"
										if(result.bool){
											player.logSkill("cxykaobei",result.targets[0]);
											player.discardPlayerCard("he",result.targets[0],"he",true);
										}
										else {
											event.goto(0);
										}
									},
									ai:{
										expose: 0.5,
									}
								},
								cxysucai:{
									trigger:{player:"phaseUseBegin"},
									filter:function(event,player){
										return player.isDamaged();
									},
									direct:true,
									content:function(){
										"step 0"
										event.num = 2*(player.maxHp - player.hp);
										var skillprompt = "是否发动<cS>素材</cS>";
										skillprompt += "<p>你可以摸"+get.cnNumber(event.num)+"张牌，然后弃牌阶段你改为弃置"+get.cnNumber(event.num)+"张牌</p>";
										player.chooseBool(skillprompt);
										"step 1"
										if(result.bool){
											player.logSkill("cxysucai");
											player.draw(event.num);
											player.addTempSkill("cxysucai_effect",{player:["phaseDiscardAfter","phaseEnd"]});
											player.storage.cxysucai_effect = event.num;
										}
									},
									ai:{
										maixie:true,
										effect:{
											target:function(card,player,target){
												if(target.maxHp<=3) return;
												if(get.tag(card,'damage')){
													if(!target.hasFriend())return ;
													if(target.hp==target.maxHp) return [0,1];
												}
												if(get.tag(card,'recover')&&player.hp>=player.maxHp-1) return [0,0];
											}
										}
									},
									subSkill:{
										effect:{
											init:function(player){
												player.storage.cxysucai_effect = 0;
											},
											onremove:function(player){
												delete player.storage.cxysucai_effect;
											},
											trigger:{player:"phaseDiscardBegin"},
											forced:true,
											content:function(){
												"step 0"
												player.chooseToDiscard('he',player.storage.cxysucai_effect,true);
												"step 1"
												trigger.untrigger();
												trigger.finish();
											}
										}
									},
								},
								cxyweitiao:{
									trigger:{player:"phaseDiscardEnd"},
									priority: 2,
									filter:function(event,player){
										return player.storage.cxyweitiao&&player.storage.cxyweitiao!=-1&&player.storage.cxyweitiao.length>1;
									},
									direct:true,
									content:function(){
										"step 0"
										var skillprompt = "是否发动<cS>微调</cS>";
										skillprompt += "<p>"+get.translation("cxyweitiao_info")+"</p>";
										player.chooseBool(skillprompt).ai=function(){
											return game.hasPlayer(function(current){
												return current!=player&&get.attitude(player,current)<2&&current.num('he');
											});
										};
										"step 1"
										if(result.bool){
											player.chooseTarget(function(card,player,target){
												return target!=player&&target.num('he');
											}).ai=function(target){
												return 2 - get.attitude(player,target);
											};
										}
										else {
											event.goto(0);
										}
										"step 2"
										if(result.bool){
											player.logSkill("cxyweitiao",result.targets);
											player.discardPlayerCard(result.targets[0],'he',true);
										}
									},
									group:["cxyweitiao_sub1","cxyweitiao_sub2","cxyweitiao_sub3"],
									subSkill:{
										sub1:{
											trigger:{player:"phaseDiscardBefore"},
											direct:true,
											content:function(){
												player.storage.cxyweitiao = [];
											}
										},
										sub2:{
											trigger:{player:"phaseDiscardEnd"},
											priority: -15,
											direct:true,
											content:function(){
												delete player.storage.cxyweitiao;
											}
										},
										sub3:{
											trigger:{player:"discard"},
											filter:function(event,player){
												return player.storage.cxyweitiao&&player.storage.cxyweitiao!=-1;
											},
											direct:true,
											content:function(){
												for(var i=0;i<trigger.cards.length;i++){
													var type = get.type(trigger.cards[i]);
													if(player.storage.cxyweitiao.contains(type)){
														player.storage.cxyweitiao = -1;
														break;
													}
													player.storage.cxyweitiao.push(type);
												}
											},
										}
									}
								},
								cxybaihe:{
									trigger:{player:"phaseDrawBegin"},
									filter:function(event,player){
										return game.hasPlayer(function(current){
											return current.sex == "female";
										});
									},
									direct:true,
									content:function(){
										"step 0"
										event.num = game.filterPlayer(function(current){
											return current.sex == "female";
										}).length;
										var skillprompt = "是否发动<cS>百合</cS>";
										skillprompt += "<p style='text-align:center;'>你可以额外摸"+get.cnNumber(event.num)+"张牌</p>";
										player.chooseBool(skillprompt);
										"step 1"
										if(result.bool){
											player.logSkill("cxybaihe");
											trigger.num += event.num;
										}
									},
								},
								cxysanren:{
									init:function(player){
										player.storage.cxysanren = [];
									},
									enable:"phaseUse",
									usable:3,
									selectCard:1,
									filterCard:function(card){
										var player = _status.currentPhase;
										return !player.storage.cxysanren.contains(card.name);
									},
									selectTarget:1,
									filterTarget:function(card,player,target){
										return target!=player&&player.canUse({name:"sha"},target,false);
									},
									check:function(card){
										return 8 - get.value(card);
									},
									content:function(){
										player.storage.cxysanren.push(cards[0].name);
										player.useCard({name:"sha"},target,false);
									},
									ai:{
										order: 4,
										result:{
											target:function(player,target){
												return get.effect(target,{name:"sha"},player,target);
											}
										}
									}
								}
							},
							translate:{
								nonameba:"吧友列传",
								BYLZ:"杀",
				
								dachengcheng:"大橙橙",
								kelejiabing:"可乐加冰",
								jielianjun:"戒联君",
								laochanchan:"老郸郸",
								xiwangjiaozhu:"希望教主",
								manduxun:"满都迅",
								bohetang:"薄荷糖",
								jiaotang:"椒盐焦糖君",
								
								xueyan531:"血焱",
								Sukincen:"苏金神",
								liusha:"流沙",
								jianxiake:"剑侠客",
								
								daima:"代码",
								chengxu:"程序",
								shuibi:"水笔",
								duangeng:"断更",
								xiangsu:"像素",
								koutu:"抠图",
								chigua:"吃瓜",
								jiwang:"寄望",
								guangmang:"光芒",
								shuiyou:"水友",
								qiji:"奇迹",
								yaowan:"药丸",
								bohe:"薄荷",
								qianshui:"潜水",
								maopao:"冒泡",
								fenzhi:"分置",
								cxytansuo:"探索",
								cxykaobei:"拷贝",
								cxysucai:"素材",
								cxyweitiao:"微调",
								cxybaihe:"百合",
								cxysanren:"三刃",
								
								"qianshui_info":"回合结束时，你可以摸x张牌(x为你装备区牌的数量)并弃置等量的牌，若弃置的牌中有装备牌，则直到你的下一回合开始，你的防御距离+1。",
								"maopao_info":"当你造成/受到伤害后，你/伤害来源可以移动/弃置目标角色/你装备区的一张牌。",
								"yaowan_info":"锁定技，你的手牌数始终为0。",
								"bohe_info":"当你需要使用或打出牌时，你可以观看牌堆顶的五张牌，若其中有你可以使用或打出的牌，则你可以使用或打出之。",
								"qiji_info":"锁定技，出牌阶段结束时，若你的手牌数为场上最多(或之一)，你失去1体力；否则，你摸一张牌，然后弃置场上的一张牌。",
								"shuiyou_info":"锁定技，摸牌阶段你改为摸x张牌（x为你已损失的体力值）；当你受到1点伤害后，你的手牌上限+1。",
								"guangmang_info":"锁定技，准备阶段，若你有寄望牌，则你将之置入弃牌堆并回复1点体力，然后你可以视为使用一张杀(无距离限制)。",
								"jiwang_info":"每轮限一次，当你受到伤害后，你可以将场上的一张牌置于你的武将牌上，称为寄望。",
								"chigua_info":"锁定技，当你受到伤害后，你摸一张牌，然后永久获得以下一项效果：1.使用[杀]无距离限制；2.使用[杀]额外指定一名目标；3.使用[杀]的次数限制+1；若已获得全部效果，则改为额外摸一张牌。",
								"koutu_info":"出牌阶段,你可以将至多三张手牌当一张你第x次获得的像素使用（x为这些牌的点数之和），然后移除该像素。",
								"xiangsu_info":"当你于出牌阶段使用牌时，若此阶段你未使用过同类别的牌，你可以摸一张牌并随机获得一个普通锦囊的名字，称为像素。",
								"duangeng_info":"觉醒技，准备阶段，若你从上一回合开始于摸牌阶段外获得的牌小于游戏轮数，你需增加1点体力上限，然后失去技能水笔。",
								"shuibi_info":"其他角色出牌阶段开始时，若其手牌数不少于你，你可以与其同时展示一张手牌，若展示的牌点数之和为偶数，则你摸一张牌并弃置其展示的牌。",
								"chengxu_info":"当你使用杀指定目标后，若其体力值小于此杀点数，你可以令此杀不可被闪响应并弃置其装备区与手牌区的防具牌。",
								"daima_info":"锁定技，你对体力值小于你的角色使用杀无距离限制。",
								"fenzhi_info":"每回合限一次，当你受到伤害后，你可以摸一张牌，然后展示一张手牌，令伤害来源选择一项：1.摸一张牌并翻面；2.弃置一张装备牌，然后不能使用或打出与展示的牌类型相同的牌。",
								"cxytansuo_info":"当你受到伤害后，你可以弃置一张牌并声明一种牌的类型，然后从牌堆顶亮出五张牌，获得其中与你所声明类型相同的牌，将其余的牌置入弃牌堆。",
								"cxykaobei_info":"当你因弃置而失去装备区的牌时，你可以弃置其他角色的一张牌。",
								"cxysucai_info":"出牌阶段开始时，若你已受伤，你可以摸2x张牌(x为你已损失的体力值)，若如此做，弃牌阶段你改为弃置等量的牌。",
								"cxyweitiao_info":"弃牌阶段结束时，若你于此阶段内弃置的牌类别均不同，你可以弃置其他角色的一张牌。",
								"cxybaihe_info":"摸牌阶段，你可以额外摸x张牌(x为女性角色数)。",
								"cxysanren_info":"出牌阶段限三次，你可以弃置一张手牌(不能与你本局游戏中以此法弃置的牌同名)，视为使用一张[杀](不计次数且无视距离)。",
							},
						}
					}
				);
				lib.config.all.sgscharacters.push("nonameba");
				lib.config.all.characters.push("nonameba");
				lib.config.characters.push("nonameba");
				get.groupnature = function(group,method){
					var nature;
					switch(group){
						case 'shen':nature='thunder';break;
						case 'wei':nature='water';break;
						case 'shu':nature='soil';break;
						case 'wu':nature='wood';break;
						case 'qun':nature='metal';break;
						default:nature = group;break;
					}
					if(method=='raw'){
						return nature;
					}
					return nature+'mm';
				};
			},
			editable:false,
			config:{
				intro:{
                    name:'简介：以无名杀贴吧吧友作为武将形象的扩展包，支持联机。',
                    clear:true,
					nopointer:true,
                },
			}
		}
	}
);
